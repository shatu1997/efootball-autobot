package com.example.efbot;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 48, 36, 36);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title = new TextView(this);
        title.setText("eFootball AutoTap — Prototype");
        title.setTextSize(22);
        root.addView(title);
        TextView note = new TextView(this);
        note.setText("This starter project does not play eFootball intelligently. It only provides an Android AccessibilityService scaffold for user-authorized experiments. Use only where permitted; online automation may violate game rules.");
        note.setTextSize(16);
        note.setPadding(0, 24, 0, 24);
        root.addView(note);
        Button settings = new Button(this);
        settings.setText("Open Accessibility Settings");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(settings);
        TextView status = new TextView(this);
        status.setText("Next: implement and test your own safe, user-triggered gestures. This sample intentionally does not auto-tap a live match.");
        status.setTextSize(14);
        status.setPadding(0, 24, 0, 0);
        root.addView(status);
        setContentView(root);
    }
}
