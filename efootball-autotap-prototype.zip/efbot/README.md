# eFootball AutoTap Prototype (Android)

This is a starter Android project that builds a debug APK through GitHub Actions. It is **not an AI that plays eFootball**; no game-state recognition, passing/shooting strategy, or automatic match control is included.

## Build an APK with GitHub
1. Create a GitHub repository and upload these files (keep the `.github/workflows/build-apk.yml` path).
2. Open the repository's **Actions** tab and select **Build Android APK**.
3. Press **Run workflow** (or push to `main`) and wait for the workflow to finish.
4. Open the completed run, scroll to **Artifacts**, and download `efootball-autotap-prototype-debug-apk`.
5. Extract the ZIP to get `app-debug.apk`. Android may ask you to allow installation from that source.

## Notes
- This is a minimal buildable scaffold, not a finished bot.
- The Accessibility service is intentionally not performing automatic taps. Implementing robust game-playing AI requires visual state detection, decision logic, and extensive device-specific testing.
- Use automation only in modes and ways allowed by the game's rules. Online botting may risk account penalties.
